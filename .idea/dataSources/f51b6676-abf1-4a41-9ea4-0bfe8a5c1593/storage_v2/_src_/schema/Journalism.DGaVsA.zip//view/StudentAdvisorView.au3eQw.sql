CREATE VIEW StudentAdvisorView AS
  SELECT
    `Student`.`ID`        AS `StudentID`,
    `Advisor`.`ID`        AS `AdvisorID`,
    `Advisor`.`FirstName` AS `FirstName`,
    `Advisor`.`LastName`  AS `LastName`,
    `Advisor`.`KSCEmail`  AS `KSCEmail`
  FROM ((`Journalism`.`User` `Student`
    JOIN `Journalism`.`Student_Advisor` ON ((`Journalism`.`Student_Advisor`.`StudentID` = `Student`.`ID`))) JOIN
    `Journalism`.`User` `Advisor` ON ((`Advisor`.`ID` = `Journalism`.`Student_Advisor`.`AdvisorID`)));

