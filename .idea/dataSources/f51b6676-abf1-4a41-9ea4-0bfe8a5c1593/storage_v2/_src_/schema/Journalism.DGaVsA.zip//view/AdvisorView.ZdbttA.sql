CREATE VIEW AdvisorView AS
  SELECT
    `Journalism`.`User`.`ID`        AS `ID`,
    `Journalism`.`User`.`FirstName` AS `FirstName`,
    `Journalism`.`User`.`LastName`  AS `LastName`,
    `Journalism`.`User`.`KSCEmail`  AS `KSCEmail`,
    `Journalism`.`User`.`AltEmail`  AS `AltEmail`
  FROM `Journalism`.`User`
  WHERE (`Journalism`.`User`.`UserType` = 2)
  ORDER BY `Journalism`.`User`.`ID`;

