CREATE VIEW CourseView AS
  SELECT
    `Journalism`.`Course`.`ID`           AS `ID`,
    `Journalism`.`CoursePrefix`.`Prefix` AS `Prefix`,
    `Journalism`.`Course`.`Number`       AS `Number`,
    `Journalism`.`Course`.`Name`         AS `Name`
  FROM (`Journalism`.`Course`
    JOIN `Journalism`.`CoursePrefix` ON ((`Journalism`.`Course`.`Prefix` = `Journalism`.`CoursePrefix`.`ID`)));

