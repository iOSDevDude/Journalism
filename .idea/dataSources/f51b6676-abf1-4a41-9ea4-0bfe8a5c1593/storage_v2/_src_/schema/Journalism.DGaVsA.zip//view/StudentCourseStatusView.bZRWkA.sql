CREATE VIEW StudentCourseStatusView AS
  SELECT
    `StudentView`.`ID`                               AS `StudentID`,
    `CourseView`.`ID`                                AS `CourseID`,
    `CourseView`.`Prefix`                            AS `Prefix`,
    `CourseView`.`Number`                            AS `Number`,
    `CourseView`.`Name`                              AS `Name`,
    `Journalism`.`Student_Course`.`CompletionStatus` AS `CompletionStatus`
  FROM ((`Journalism`.`StudentView`
    JOIN `Journalism`.`Student_Course` ON ((`Journalism`.`Student_Course`.`StudentID` = `StudentView`.`ID`))) JOIN
    `Journalism`.`CourseView` ON ((`CourseView`.`ID` = `Journalism`.`Student_Course`.`CourseID`)));

