CREATE VIEW StudentView AS
  SELECT
    `Journalism`.`User`.`ID`               AS `ID`,
    `Journalism`.`User`.`FirstName`        AS `FirstName`,
    `Journalism`.`User`.`LastName`         AS `LastName`,
    `Journalism`.`User`.`KSCEmail`         AS `KSCEmail`,
    `Journalism`.`User`.`AltEmail`         AS `AltEmail`,
    `Journalism`.`Classification`.`Class`  AS `Class`,
    `Journalism`.`Student`.`CatalogYear`   AS `CatalogYear`,
    `Journalism`.`Student`.`MajorDeclared` AS `MajorDeclared`,
    `Journalism`.`JRNOption`.`Type`        AS `Type`,
    `Journalism`.`Student`.`MinorDeclared` AS `MinorDeclared`
  FROM (((`Journalism`.`User`
    JOIN `Journalism`.`Student` ON ((`Journalism`.`Student`.`UserID` = `Journalism`.`User`.`ID`))) JOIN
    `Journalism`.`JRNOption` ON ((`Journalism`.`Student`.`JRNOption` = `Journalism`.`JRNOption`.`ID`))) JOIN
    `Journalism`.`Classification` ON ((`Journalism`.`Student`.`Classification` = `Journalism`.`Classification`.`ID`)))
  ORDER BY `Journalism`.`User`.`ID`;

